using UnityEngine;
using Flandre.CombatSystem;

/// <summary>
/// 【强行打出的僵直】—— 弱化版蓄力的代价。
///
/// ==========================================================
/// 【为什么必须是一个 State，而不是把后摇调长】
///
/// 上一版把惩罚做成「加长该手的 recoveryTime」，有三个问题：
///
///   ① 粒度错了 —— handBusyUntil 只锁【一只手】。另一只手照常出招，
///      而设计意图是"这段时间你什么都做不了"。
///   ② 空中漏了 —— 后摇不改变状态，角色还待在 FallState 里，
///      于是掉落途中方向键照常生效，落地才被 Idle/Run 的后摇检查拦住。
///      倒计时却是从出招那一刻就开始走的，等于空中那段惩罚白送。
///   ③ 打断没有出口 —— 后摇是个时间戳，没有"被别的事情中止"的概念。
///
/// 做成状态之后三个问题一起消失：状态天然是全局的、天然管住空中，
/// 而"被打断"就是状态机本来就在做的事 —— 受击时 HandlePlayerHit
/// 会无条件 ChangeState(hitState)，僵直自然被接管，不需要任何额外代码。
/// ==========================================================
///
/// 【什么时候进来】
/// 只在弱化版蓄力【自然演完】时进入（动画事件结束 / 兜底超时）。
/// 被冲刺、滑铲主动取消掉的不进 —— 那种情况玩家已经付了一次位移 CD，
/// 而且从 Exit 里发起状态切换会和正在进行的切换打架。
/// </summary>
public class ChargeStunState : PlayerStateBase
{
    private float timer;
    private float duration;

    // ---- 预付的逃逸冲劲 ----
    private bool pendingEscape;
    private bool pendingEscapeIsDash;
    private float pendingEscapeDirection = 1f;

    // 本次僵直里冲劲的运行时状态
    private float escapeSpeed;
    private float escapeDirection;
    private float escapeElapsed;
    private float escapeDuration;

    private PlayerMovementConfig MoveCfg
        => sm.playerState != null ? sm.playerState.movementConfig : null;

    public ChargeStunState(PlayerStateMachine stateMachine) : base(stateMachine) { }

    /// <summary>设定本次僵直时长。必须在 ChangeState 之前调用</summary>
    public void SetDuration(float seconds)
    {
        duration = Mathf.Max(0f, seconds);
    }

    /// <summary>
    /// 【预付冲刺 / 滑铲换来的初速度】
    ///
    /// 由路由器在【弱化蓄力动画期间】收到冲刺/滑铲时写入。
    ///
    /// 那一下不会真的进入 DashState / SlideState —— 否则僵直直接被跳过，
    /// 惩罚形同虚设。它只兑换成一股初速度，在僵直里自行衰减：
    /// 玩家依然全程不能操作，但能带着这股冲劲滑出去一段。
    ///
    /// 于是"想脱离"这件事仍然要付代价（一次冲刺 CD），
    /// 拿到的却不是自由，而是一个【方向在按下那一刻就定死】的位移。
    /// </summary>
    /// <param name="isDash">true = 冲刺兑换的，false = 滑铲兑换的。决定读哪个初速度</param>
    /// <param name="direction">1 = 右，-1 = 左。按下那一刻定死，僵直里改不了</param>
    public void SetEscapeMomentum(bool isDash, float direction)
    {
        pendingEscape = true;
        pendingEscapeIsDash = isDash;
        pendingEscapeDirection = direction >= 0f ? 1f : -1f;
    }

    /// <summary>剩余僵直秒数。供 UI 显示</summary>
    public float Remaining => Mathf.Max(0f, timer);

    public override void Enter()
    {
        timer = duration;

        // 重力恢复出厂值：可能是从空中蓄力的"钉住"状态一路过来的
        sm.rb.gravityScale = sm.defaultGravityScale;

        // 只清水平速度。Y 轴留给重力 —— 空中僵直应该是【直着掉下去】，
        // 而不是浮在半空，那看起来像卡死。
        sm.rb.linearVelocity = new Vector2(0f, sm.rb.linearVelocity.y);

        // 把已经攒下的输入全部倒掉。
        // 僵直期内的新输入会被入口挡住（见 ComboInputBuffer.AcceptsAttackInput
        // 与 PlayerCommandRouter.OnCommand），但【进来之前】按下的那些还在缓存里，
        // 不清的话僵直一结束就会集体兑现，角色自己动起来。
        sm.commandRouter?.ClearBuffer();
        sm.inputBuffer?.ClearHandRecovery();   // 顺带清掉两只手的后摇与长按意图
        sm.inputBuffer?.ResetCombo();

        // 【正在进行中的蓄力也要掐掉】—— 缓存清得再干净也管不到它。
        //
        // 弱蓄的动画还在演时，另一只手是自由的，长按会真的开始蓄力：
        // 那不是待兑现的"预输入"，而是一个每帧都在涨的活体进程。
        // 进僵直只清缓存的话，它照常蓄满，松手照常打出 ——
        // 表现出来就是「交替长按左右键，在僵直里无限复读 AA1/BB1」。
        //
        // 后果与被受击打断一致：什么都不放（HandlePlayerHit 也是这么做的）。
        sm.chargeSystem?.CancelAll();

        // 取出预付的冲劲。
        //
        // 【不复用 slideMomentum】滑铲那套是匀减速（直线），
        // 而逃逸冲劲要的是"先几乎不掉速、越到后面掉得越快"的抛物线尾巴，
        // 两条曲线形状不同、调参目标也不同，硬共用会互相牵制。
        escapeElapsed = 0f;
        escapeSpeed = 0f;
        escapeDuration = 0f;

        if (pendingEscape)
        {
            var cfg = MoveCfg;

            escapeSpeed = pendingEscapeIsDash
                ? (cfg != null ? cfg.escapeDashSpeed : 12f)
                : (cfg != null ? cfg.escapeSlideSpeed : 7f);

            escapeDuration = cfg != null ? cfg.escapeDuration : 0.8f;
            escapeDirection = pendingEscapeDirection;

            pendingEscape = false;
        }

        // TODO: 美术资源到位后换成专门的僵直动画（喘息 / 踉跄）。
        // 现在借用待机与下落，至少保证不会停在攻击动画的最后一帧上。
        sm.animDriver.SetBase(
            sm.IsGrounded() ? PlayerAnimHash.Idle : PlayerAnimHash.JumpFall,
            restart: true);
    }

    public override void Update()
    {
        timer -= Time.deltaTime;

        if (timer <= 0f)
        {
            if (!sm.IsGrounded()) sm.ChangeState(sm.fallState);
            else HandleLanding();
            return;
        }

        // 空中僵直期间落了地 → 动画换成站姿，但僵直【继续走完】。
        // 倒计时不因为落地而缩短，否则"在高处放"就成了逃避惩罚的技巧。
        if (sm.IsGrounded()) sm.animDriver.SetBase(PlayerAnimHash.Idle);
    }

    public override void FixedUpdate()
    {
        // 预付的冲劲优先。玩家在这段时间里【依然不能操作】——
        // 方向、跳跃、冲刺全部无效，只是身体带着按下那一刻定死的方向滑出去。
        if (TickEscapeMomentum()) return;

        // 没有冲劲（或已衰减完）：每帧按住水平速度为 0。
        // 方向键在僵直期间完全无效，地面空中一视同仁 ——
        // 这正是空中那个 bug 的修复处：以前角色留在 FallState 里，
        // 掉落途中 ApplyHorizontalMove 照常响应方向键。
        sm.rb.linearVelocity = new Vector2(0f, sm.rb.linearVelocity.y);
    }

    /// <summary>
    /// 【逃逸冲劲的衰减曲线】开口向下抛物线的右半部分。
    ///
    ///     速度 = 初速度 × (1 - (t / 总时长) ^ 指数)
    ///
    /// 指数 = 2 时，t=0 处斜率为 0（起步几乎不掉速），
    /// 越接近尾声掉得越快，末端一口气归零 —— 就是"先飘一段再急刹"的手感。
    /// 指数 = 1 退化成匀减速；调大则飘得更久、刹得更狠。
    ///
    /// 【为什么写成"按已过时间求值"而不是"每帧减一点"】
    /// 逐帧累减的话，实际曲线会受帧率影响，而且改指数要重推减速率。
    /// 直接对时间求值则曲线形状是确定的，参数所见即所得，
    /// 位移总距离也有闭式解：初速度 × 总时长 × 指数/(指数+1)。
    /// </summary>
    /// <returns>本帧是否由冲劲接管了水平速度</returns>
    private bool TickEscapeMomentum()
    {
        if (escapeDuration <= 0f || escapeSpeed <= 0f) return false;
        if (escapeElapsed >= escapeDuration) return false;

        escapeElapsed += Time.fixedDeltaTime;

        float t = Mathf.Clamp01(escapeElapsed / escapeDuration);
        float exponent = MoveCfg != null ? Mathf.Max(0.01f, MoveCfg.escapeDecayExponent) : 2f;

        float factor = 1f - Mathf.Pow(t, exponent);

        sm.rb.linearVelocity = new Vector2(
            escapeDirection * escapeSpeed * factor,
            sm.rb.linearVelocity.y);

        return true;
    }

    public override void Exit()
    {
        timer = 0f;
        duration = 0f;

        // 没用掉的预付冲劲不留到下一次僵直去
        pendingEscape = false;
        escapeSpeed = 0f;
        escapeDuration = 0f;
        escapeElapsed = 0f;
    }
}
