using UnityEngine;
using Flandre.CombatSystem;

/// <summary>
/// 冲刺状态。
///
/// 【批次A 改动】
///   1. HandleFallback 里的 Input.GetAxisRaw("Horizontal") → 改读虚拟手柄
///   2. 无敌请求改用引用计数（RequestUntargetable / ReleaseUntargetable），
///      不再与受击无敌抢同一个布尔开关
///
/// 【本次刻意未动 · 后续阶段处理】
///   - 那一大段 if (sm.isDashRelay) { 传送 / 生成锚点 / 切图层 } → 阶段2 全部交给宝石
///   - isRejected 补丁字段与「在 Enter() 里调用 ChangeState()」的重入问题 → 阶段3 守卫前置
///   - 物理写在 Update() 而非 FixedUpdate() → 阶段4
/// </summary>
public class DashState : IState
{
    private PlayerStateMachine sm;
    private float dashTimer;
    private float originalGravity;
    private bool isFirstHit;

    // 防 CD 递归污染标记 (阶段3 守卫前置后可删除)
    private bool isRejected;

    private readonly int playerLayer = LayerMask.NameToLayer("Player");
    private readonly int invincibleLayer = LayerMask.NameToLayer("Invincible");

    public DashState(PlayerStateMachine stateMachine) { sm = stateMachine; }

    public void Enter()
    {
        isRejected = false;
        sm.playerController.loadoutManager.ExecuteActionModifier(ActionType.Dash);

        if (!sm.dashSkill.CanExecute())
        {
            Debug.LogWarning("[Dash] CD或硬直中！拦截执行");
            isRejected = true;
            HandleFallback();
            return;
        }

        isFirstHit = (sm.dashSkill.currentCombo == 0);
        sm.dashSkill.Execute();

        // ==========================================
        // 【逻辑分流 1】Relay 第二段：强制传送并退出
        // (阶段2 由 RelayGem.OnActionEnter 返回 Override 接管)
        // ==========================================
        if (!isFirstHit && sm.isDashRelay)
        {
            sm.transform.position = sm.dashAnchorPos;
            sm.rb.linearVelocity = Vector2.zero;
            Debug.Log("[Dash] Relay 传送触发！");

            isRejected = true;
            HandleFallback();
            return;
        }

        // ==========================================
        // 【逻辑分流 2】常规冲刺 (含首冲与 Echo 的二冲)
        // ==========================================
        if (isFirstHit && sm.isDashRelay)
        {
            sm.dashAnchorPos = sm.transform.position;

            // 【批次A 改动】引用计数式无敌：
            // 签名传 this，与受击无敌(InvulnerableTokens.HitStun)互不干扰。
            // 就算受击无敌在这期间到期解除，也不会误关掉冲刺无敌。
            sm.playerState.health.RequestUntargetable(this);

            sm.gameObject.layer = invincibleLayer; // 玩家可穿过敌人

            if (sm.anchorPrefab != null)
                sm.activeDashAnchor = GameObject.Instantiate(sm.anchorPrefab, sm.dashAnchorPos, Quaternion.identity);
        }

        // ----- 正常冲刺的物理与视觉表现 -----
        Debug.Log("进入了：冲刺状态");
        if (sm.dashTrail != null) sm.dashTrail.emitting = true;

        dashTimer = sm.dashDuration;
        originalGravity = sm.rb.gravityScale;
        sm.rb.gravityScale = 0f;

        float direction = sm.playerController.facingDirection;
        sm.rb.linearVelocity = new Vector2(direction * sm.dashSpeed, 0f);
    }

    public void Update()
    {
        dashTimer -= Time.deltaTime;
        if (dashTimer <= 0)
        {
            sm.rb.gravityScale = originalGravity;
            HandleFallback();
        }
    }

    public void Exit()
    {
        if (isRejected) return;

        if (sm.isDashRelay)
        {
            sm.gameObject.layer = playerLayer;

            // 【批次A 改动】释放自己那一份无敌请求
            sm.playerState.health.ReleaseUntargetable(this);
        }

        sm.dashSkill.StartCooldownIfFirstHit(isFirstHit);

        if (sm.dashTrail != null) sm.dashTrail.emitting = false;
        sm.rb.gravityScale = originalGravity;
    }

    private void HandleFallback()
    {
        // 【批次A 改动 · P0】原先这里读 Input.GetAxisRaw("Horizontal")，
        // 新输入系统下会抛异常。改为统一向虚拟手柄索要。
        float moveInputX = sm.playerController.moveInput.x;

        if (!sm.IsGrounded())
        {
            sm.ChangeState(sm.fallState);
        }
        else if (Mathf.Abs(sm.rb.linearVelocity.x) > 0.1f || Mathf.Abs(moveInputX) > 0.1f)
        {
            sm.ChangeState(sm.runState);
        }
        else
        {
            sm.ChangeState(sm.idleState);
        }
    }
}
