using UnityEngine;

namespace Flandre.CombatSystem
{
    /// <summary>
    /// 【属性面板】—— 从原本只有一个 cooldownReduction 字段的空壳，升级为真正的账本。
    ///
    /// 每一条属性都是 ModifiableStat（一面可以贴便利贴的墙）：
    ///   基础值来自 Config 说明书，宝石/buff/装备往上贴便利贴，读的时候拿最终值。
    ///
    /// 【重要】这次改动同时解决了「财务记账、收银台不看账本」的问题：
    ///   - cooldownReduction  现在真的被 ComboSkill.CanExecute() 读取
    ///   - comboWindowTolerance 现在真的被 ComboInputBuffer 的宽恕期读取
    ///   - moveSpeed          现在真的被 PlayerStateMachine.moveSpeed 转发读取
    ///
    /// 原先的 PlayerCombat 类已合并进这里（它只有一个 comboWindowTolerance
    /// 和一个只打 Debug.Log 的死方法 SetSlideCooldown）。
    /// </summary>
    [System.Serializable]
    public class PlayerStats
    {
        [Header("位移属性")]
        [Tooltip("移动速度。基础值来自 PlayerMovementConfig.moveSpeed")]
        public ModifiableStat moveSpeed = new ModifiableStat(6f);

        [Tooltip("跳跃力度")]
        public ModifiableStat jumpForce = new ModifiableStat(13f);

        [Tooltip("冲刺速度")]
        public ModifiableStat dashSpeed = new ModifiableStat(12f);

        [Header("战斗属性")]
        [Tooltip("冷却缩减，0.15 表示所有 CD 减少 15%。Echo 宝石往这里贴便利贴")]
        public ModifiableStat cooldownReduction = new ModifiableStat(0f);

        [Tooltip("连招宽恕期额外宽容度（秒）。Echo 宝石往这里贴便利贴")]
        public ModifiableStat comboWindowTolerance = new ModifiableStat(0f);

        [Tooltip("伤害倍率修正。1.0 为标准，预留给以后的宝石与装备")]
        public ModifiableStat damageMultiplier = new ModifiableStat(1f);

        private bool isInitialized = false;

        /// <summary>
        /// 从 Config 说明书灌入所有基础值。
        /// 幂等：重复调用不会出问题（内部有守卫）。
        /// </summary>
        public void Init(PlayerMovementConfig moveConfig)
        {
            if (isInitialized) return;

            if (moveConfig != null)
            {
                moveSpeed.SetBaseValue(moveConfig.moveSpeed);
                jumpForce.SetBaseValue(moveConfig.jumpForce);
                dashSpeed.SetBaseValue(moveConfig.dashSpeed);
            }

            // cooldownReduction / comboWindowTolerance / damageMultiplier
            // 的基础值就是代码里的默认值（0 / 0 / 1），不需要从 Config 灌。

            isInitialized = true;
        }

        /// <summary>
        /// 一次性撕掉某个来源在【所有】属性上贴的便利贴。
        /// 宝石 OnUnequip 时调用一次即可，不需要逐条属性去撕。
        /// </summary>
        public int RemoveAllModifiersFrom(object source)
        {
            int n = 0;
            n += moveSpeed.RemoveAllFromSource(source);
            n += jumpForce.RemoveAllFromSource(source);
            n += dashSpeed.RemoveAllFromSource(source);
            n += cooldownReduction.RemoveAllFromSource(source);
            n += comboWindowTolerance.RemoveAllFromSource(source);
            n += damageMultiplier.RemoveAllFromSource(source);
            return n;
        }

        /// <summary>
        /// 把冷却缩减套用到一个原始 CD 上，返回实际 CD。
        /// 内部做了 Clamp，防止某天叠出 120% 减 CD 导致除零或负 CD。
        /// </summary>
        public float ApplyCooldownReduction(float rawCooldown)
        {
            float cdr = Mathf.Clamp(cooldownReduction.Value, 0f, 0.9f);
            return rawCooldown * (1f - cdr);
        }
    }
}
