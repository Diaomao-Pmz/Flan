using Flandre.CombatSystem;
using UnityEngine;

/// <summary>
/// 玩家状态机。
///
/// ==========================================================
/// 【批次A 改动说明 · 请先读这段】
///
/// 本次没有对本文件做结构性瘦身（按约定留到阶段4）。
/// 本次只做了一件事：把原先散落在这里的 ~20 个调参字段，
/// 改成了指向 Config 说明书 / PlayerStats 属性面板的「转发窗口」。
///
/// 比喻：搬家时先在老地址贴个「已迁至新址」的转寄条。
///       邮差照旧往老地址送，信一样能到。
///       所以 11 个状态卡带里的 sm.moveSpeed / sm.jumpForce / sm.dashSpeed …
///       一行都不用改，编译错误接近于零。
///
/// 代价：本文件这一轮不会变短（转寄条本身占行数）。
///       真正的瘦身（拆 PlayerSensor、拆 PlayerWeaponEmitter、
///       删掉这些转发窗口）在阶段4 进行。
///
/// 【本次仍然保留为普通字段的三处，及其原因】
///   maxJumps   —— 被 GemActionProcessor 在运行时覆写，阶段2 重做宝石时一并处理
///   jumpCount  —— 运行时计数器，本来就该留在这里
///   dashSkill / slideSkill —— 内含 Inspector 已调好的数值，
///                             阶段3 会改成充能层数模型，此时不动
/// ==========================================================
/// </summary>
public class PlayerStateMachine : MonoBehaviour
{
    public IState currentState;

    public IdleState idleState;
    public RunState runState;
    public JumpState jumpState;
    public FallState fallState;
    public DashState dashState;
    public CrouchState crouchState;
    public SlideState slideState;
    public FlyState flyState;

    public ComboState comboState;

    public ChargeState chargeState;
    public HitState hitState;

    public Animator anim;
    public Rigidbody2D rb;
    public TrailRenderer dashTrail;         // 尾迹
    public PlayerController playerController;
    public PlayerState playerState;

    // ==========================================================
    // 转发窗口：Config 说明书的快捷方式
    // ==========================================================
    private PlayerMovementConfig MoveCfg => playerState != null ? playerState.movementConfig : null;
    private PlayerCombatConfig CombatCfg => playerState != null ? playerState.combatConfig : null;

    // ==========================================================
    // 【转发窗口】Run —— 走属性面板（可被宝石贴便利贴）
    // ==========================================================
    public float moveSpeed => playerState.stats.moveSpeed.Value;

    // ==========================================================
    // 【转发窗口】Jump
    // ==========================================================
    [Header("Jump Runtime (运行时计数器，非配置)")]
    [Tooltip("最大跳跃次数。基础值来自 Config，但目前仍会被 GemActionProcessor 运行时覆写 —— 阶段2 修复")]
    public int maxJumps = 1;
    [Tooltip("当前已跳跃次数")]
    public int jumpCount = 0;

    public float jumpForce => playerState.stats.jumpForce.Value;
    public float minJumpVelocity => MoveCfg.minJumpVelocity;

    [Header("场景引用 (不属于配置，保留在此)")]
    public Transform groundCheck;           // 脚底传感器
    public LayerMask groundLayer;           // 什么图层算是地面

    // ==========================================================
    // 【转发窗口】Dash
    // ==========================================================
    public float dashSpeed => playerState.stats.dashSpeed.Value;
    public float dashDuration => MoveCfg.dashDuration;

    [Header("Dash / Slide 充能配置 (阶段3 改为充能层数模型)")]
    public ComboSkill dashSkill = new ComboSkill();
    public ComboSkill slideSkill = new ComboSkill();

    // ==========================================================
    // 【转发窗口】Slide / Crouch
    // ==========================================================
    public float slideStartSpeedMultiplier => MoveCfg.slideStartSpeedMultiplier;
    public float slideDeceleration => MoveCfg.slideDeceleration;

    /// <summary>滑铲降速到 moveSpeed * 本倍率 时转入蹲下（原名保留，避免改动状态卡带）</summary>
    public float crouchSpeedMultiplier => MoveCfg.slideToCrouchSpeedMultiplier;

    /// <summary>蹲行移动速度倍率。原先在 CrouchState 里硬编码为 0.5</summary>
    public float crouchMoveSpeedMultiplier => MoveCfg.crouchMoveSpeedMultiplier;

    [Header("Crouch 场景引用")]
    public Transform ceilingCheck;          // 头顶雷达
    public Transform hurtboxCore;           // 受击小框
    [HideInInspector] public BoxCollider2D coll;
    [HideInInspector] public Vector2 originalColliderSize;
    [HideInInspector] public Vector2 originalColliderOffset;
    private Vector3 originalHurtboxPos;

    // ==========================================================
    // 【转发窗口】Hit
    // ==========================================================
    public float hitStunDuration => CombatCfg.hitStunDuration;
    public Vector2 hitKnockbackForce => CombatCfg.hitKnockbackForce;
    public float blinkInterval => CombatCfg.blinkInterval;

    // ==========================================================
    // 【转发窗口】Shoot
    // ==========================================================
    [Header("Shoot 场景引用")]
    [Tooltip("远程子弹预制体")]
    public GameObject projectilePrefab;
    [Tooltip("子弹发射的枪口位置")]
    public Transform firePoint;

    public float projectileSpeed => CombatCfg.projectileSpeed;

    // ==========================================================
    // 【转发窗口】Fly
    // ==========================================================
    public float hoverChargeTime => MoveCfg.hoverChargeTime;
    public float flyManaCostPerSecond => MoveCfg.flyManaCostPerSecond;
    public float flyCancelJumpForce => MoveCfg.flyCancelJumpForce;
    public float flySpeed => MoveCfg.flySpeed;

    // ==========================================================
    // Relay 运行时数据 (阶段2 全部搬进 RelayGemRuntime，本次不动)
    // ==========================================================
    [HideInInspector] public Vector2 dashAnchorPos;
    [HideInInspector] public Vector2 slideAnchorPos;
    [HideInInspector] public Vector2 jumpAnchorPos;

    [Header("Relay Visuals")]
    public GameObject anchorPrefab;
    [HideInInspector] public GameObject activeDashAnchor;
    [HideInInspector] public GameObject activeSlideAnchor;
    [HideInInspector] public GameObject activeJumpAnchor;

    [HideInInspector] public bool isDashRelay = false;
    [HideInInspector] public bool isSlideRelay = false;
    [HideInInspector] public bool isJumpRelay = false;
    [HideInInspector] public bool hasJumpAnchor = false;

    // 缓存，避免每帧 GetComponent
    private ComboInputBuffer cachedInputBuffer;
    public ComboInputBuffer inputBuffer
    {
        get
        {
            if (cachedInputBuffer == null) cachedInputBuffer = GetComponent<ComboInputBuffer>();
            return cachedInputBuffer;
        }
    }

    void Awake()
    {
        playerController = GetComponent<PlayerController>();
        playerState = GetComponent<PlayerState>();
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        coll = GetComponent<BoxCollider2D>();
        cachedInputBuffer = GetComponent<ComboInputBuffer>();

        // 【关键】不依赖 Unity 的组件 Awake 顺序：
        // 无论 PlayerState 先醒还是我先醒，这一句都保证数据已就绪。
        if (playerState != null)
        {
            playerState.EnsureInitialized();

            // 让两个 ComboSkill 能读到冷却缩减 —— 接通「财务记账、收银台不看账本」的断链
            dashSkill.BindStats(playerState.stats);
            slideSkill.BindStats(playerState.stats);

            // 从说明书取跳跃次数基础值（之后仍可能被宝石覆写，阶段2 修复）
            if (playerState.movementConfig != null)
            {
                maxJumps = playerState.movementConfig.maxJumps;
            }
        }
        else
        {
            Debug.LogError("[PlayerStateMachine] 找不到 PlayerState 组件！所有配置转发都会失败。", this);
        }

        if (coll != null)
        {
            originalColliderSize = coll.size;
            originalColliderOffset = coll.offset;
        }

        idleState = new IdleState(this);
        runState = new RunState(this);
        jumpState = new JumpState(this);
        fallState = new FallState(this);
        dashState = new DashState(this);
        crouchState = new CrouchState(this);
        slideState = new SlideState(this);
        flyState = new FlyState(this);

        comboState = new ComboState(this);

        chargeState = new ChargeState(this);
        hitState = new HitState(this);

        if (dashTrail == null) dashTrail = GetComponentInChildren<TrailRenderer>();

        if (hurtboxCore != null)
        {
            originalHurtboxPos = hurtboxCore.localPosition;
        }
    }

    void Start()
    {
        // 游戏开始，强行进入待机状态
        ChangeState(idleState);

        if (playerState == null)
        {
            Debug.LogError("【致命错误】playerState 是空的！请检查 Awake 里是否忘记写 playerState = GetComponent<PlayerState>();");
        }
        else if (playerState.health == null)
        {
            Debug.LogError("【致命错误】health 模块是空的！");
        }
        else
        {
            // 养成好习惯，先取消再订阅，防止重复绑定
            playerState.health.OnPlayerHit -= HandlePlayerHit;
            playerState.health.OnPlayerHit += HandlePlayerHit;

            // TODO: 阶段4 接 DeadState 时解除注释
            // playerState.health.OnPlayerDeath -= HandlePlayerDeath;
            // playerState.health.OnPlayerDeath += HandlePlayerDeath;

            Debug.Log("【系统正常】状态机已接通受击广播，就等挨打了！");
        }
    }

    void Update()
    {
        // 落地重置（原先这段逻辑在此重复写了两遍，本次合并为一处，行为完全一致）
        if (IsGrounded() && currentState != dashState && currentState != jumpState)
        {
            jumpCount = 0;
            hasJumpAnchor = false; // 落地销毁锚点
        }

        // 后台超时监控
        if (currentState != dashState) dashSkill.UpdateTimeout();
        if (currentState != slideState) slideSkill.UpdateTimeout();

        // 锚点图片自动销毁 (阶段6 改为事件驱动，本次保持原样)
        if (dashSkill.currentCombo == 0 && activeDashAnchor != null) Destroy(activeDashAnchor);
        if (slideSkill.currentCombo == 0 && activeSlideAnchor != null) Destroy(activeSlideAnchor);
        if (!hasJumpAnchor && activeJumpAnchor != null) Destroy(activeJumpAnchor);

        // 每一帧都让当前的卡带运行
        if (currentState != null) currentState.Update();
    }

    public void ChangeState(IState newState)
    {
        if (currentState != null)
        {
            currentState.Exit();
        }

        currentState = newState;
        currentState.Enter();
    }

    // ==========================================
    // 攻击 —— 动画事件入口
    // ==========================================

    /// <summary>由动画事件调用：挥剑结束的瞬间触发，开启派生窗口</summary>
    public void OpenComboWindow()
    {
        if (currentState == comboState)
        {
            comboState.isCancelable = true;

            // 立刻结算一次：万一玩家在这个事件触发前 0.1 秒按了键，立刻生效
            inputBuffer.TryAdvanceCombo();
        }
    }

    /// <summary>由动画事件调用：收招即将结束时触发，关闭强制打断</summary>
    public void CloseComboWindow()
    {
        if (currentState == comboState)
        {
            comboState.isCancelable = false;
        }
    }

    /// <summary>由动画事件调用：动画彻底播完了</summary>
    public void OnAttackAnimationEnd()
    {
        if (currentState != comboState) return;

        ComboInputBuffer buffer = inputBuffer;
        buffer.StartGracePeriod();

        ComboNode lastNode = buffer.currentNode;
        bool isCurrentButtonHeld = false;

        if (lastNode != null)
        {
            // 根据刚放完的技能类型，去查对应的按键
            if (lastNode.inputSequence.Contains(InputCmd.MainAttack))
            {
                isCurrentButtonHeld = playerController.isMainAttackHeld;
            }
            else if (lastNode.inputSequence.Contains(InputCmd.SubAttack))
            {
                isCurrentButtonHeld = playerController.isSubAttackHeld;
            }
        }

        // 核心流转
        if (isCurrentButtonHeld)
        {
            ChangeState(chargeState);
        }
        else if (Mathf.Abs(playerController.moveInput.x) > 0.1f)
        {
            ChangeState(runState);
        }
        else
        {
            ChangeState(idleState);
        }
    }

    // ==========================================
    // 远程 (阶段4 搬去 PlayerWeaponEmitter，阶段6 接对象池)
    // ==========================================

    public void SpawnProjectile()
    {
        if (projectilePrefab == null || firePoint == null) return;

        Vector2 shootDirection;
        Vector2 inputDir = playerController.moveInput;

        if (inputDir.magnitude > 0.1f)
        {
            // 八向吸附
            float angle = Mathf.Atan2(inputDir.y, inputDir.x) * Mathf.Rad2Deg;
            angle = Mathf.Round(angle / 45f) * 45f;

            shootDirection = new Vector2(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad));

            if (shootDirection.x < -0.1f) playerController.SetFacingDirection(-1);
            else if (shootDirection.x > 0.1f) playerController.SetFacingDirection(1);
        }
        else
        {
            shootDirection = new Vector2(playerController.facingDirection, 0f);
        }

        GameObject bullet = Instantiate(projectilePrefab, firePoint.position, Quaternion.identity);
        Player_Projectile projScript = bullet.GetComponent<Player_Projectile>();
        if (projScript != null) projScript.Setup(shootDirection);
    }

    // ==========================================
    // 击飞
    // ==========================================

    private void HandlePlayerHit(Vector2 knockbackDirection)
    {
        hitState.SetKnockbackForce(knockbackDirection);
        ChangeState(hitState);

        // 让 Controller 接管画面：闪烁时长与无敌时间严格一致
        playerController.StartBlink(playerState.health.invulnerableDuration, blinkInterval);
    }

    // TODO: 阶段4 接 DeadState 时解除注释
    // private void HandlePlayerDeath()
    // {
    //     ChangeState(deadState);
    // }

    void OnDestroy()
    {
        if (playerState != null && playerState.health != null)
        {
            playerState.health.OnPlayerHit -= HandlePlayerHit;

            // TODO: 阶段4 接 DeadState 时解除注释
            // playerState.health.OnPlayerDeath -= HandlePlayerDeath;
        }
    }

    // ==========================================
    // 检测 (阶段4 整体搬去 PlayerSensor)
    // ==========================================

    public bool IsGrounded()
    {
        if (groundCheck == null) return false;

        var cfg = MoveCfg;
        Vector2 boxSize = cfg != null ? cfg.groundCheckBoxSize : new Vector2(0.5f, 0.2f);
        float distance = cfg != null ? cfg.groundCheckDistance : 0.1f;

        RaycastHit2D hit = Physics2D.BoxCast(
            groundCheck.position, boxSize, 0f, Vector2.down, distance, groundLayer);

        return hit.collider != null;
    }

    public bool CanStand()
    {
        if (ceilingCheck == null) return true; // 没挂雷达，默认允许站起

        var cfg = MoveCfg;
        Vector2 boxSize = cfg != null ? cfg.ceilingCheckBoxSize : new Vector2(0.4f, 0.1f);
        float distance = cfg != null ? cfg.ceilingCheckDistance : 0.1f;

        return !Physics2D.BoxCast(
            ceilingCheck.position, boxSize, 0f, Vector2.up, distance, groundLayer);
    }

    public void SetColliderHeight(bool isCrouching)
    {
        if (coll == null) return;

        if (isCrouching)
        {
            var cfg = MoveCfg;
            float heightMultiplier = cfg != null ? cfg.crouchColliderHeightMultiplier : 0.6f;

            coll.size = new Vector2(originalColliderSize.x, originalColliderSize.y * heightMultiplier);
            float heightDifference = originalColliderSize.y - coll.size.y;
            coll.offset = new Vector2(originalColliderOffset.x, originalColliderOffset.y - (heightDifference * 0.5f));

            // 受击小框跟着物理框一起按比例下降
            if (hurtboxCore != null)
            {
                hurtboxCore.localPosition = new Vector3(
                    originalHurtboxPos.x,
                    originalHurtboxPos.y - (heightDifference * 0.5f),
                    originalHurtboxPos.z
                );
            }
        }
        else
        {
            coll.size = originalColliderSize;
            coll.offset = originalColliderOffset;

            if (hurtboxCore != null)
            {
                hurtboxCore.localPosition = originalHurtboxPos;
            }
        }
    }
}
