using UnityEngine;
using Flandre.CombatSystem;

/// <summary>
/// 动作充能/冷却计时器。dashSkill 与 slideSkill 各持有一份。
///
/// 【批次A 改动】接通冷却缩减：
///   原先 EchoModule 老老实实往 stats.cooldownReduction 记账，
///   但全项目没有任何地方读它 —— 财务记了一整年账，收银台从来不看账本。
///   本次通过 BindStats() 把账本递给收银台。
///
/// 【尚未改动 · 阶段3 处理】
///   cdStartTime 这一个变量目前同时兼任「大CD计时」和「派生超时计时」两种语义，
///   很难读也很难扩展。阶段3 会整体换成充能层数模型
///   （最大层数 / 单层恢复时间 / 最小间隔），届时：
///     Echo  = 最大层数 +1（纯属性修饰器）
///     Relay = 层数不变，第二次使用的行为被宝石接管
///   两颗宝石的实现会变得非常干净。
/// </summary>
[System.Serializable]
public class ComboSkill
{
    [Header("时间与连段配置")]
    public float totalCD = 2.0f;        // 动作大CD
    public float interval = 0.15f;      // 连按硬直限制
    public float comboWindow = 0.3f;    // 派生超时等待窗口期
    public int maxCombo = 1;            // 最大连段数（默认1，宝石可改）

    public int currentCombo { get; private set; } = 0;

    // 复用计时器：平时当大CD用，连段中当「派生超时计时器」用
    private float cdStartTime = -10f;
    private float lastTapTime = -10f;

    // 【批次A 新增】属性面板引用，用于读取冷却缩减
    private PlayerStats stats;

    /// <summary>
    /// 由 PlayerStateMachine.Awake() 注入属性面板。
    /// 不注入也能正常工作（退化为无冷却缩减），因此不会因为忘记调用而崩溃。
    /// </summary>
    public void BindStats(PlayerStats playerStats)
    {
        stats = playerStats;
    }

    /// <summary>实际生效的大CD = 原始CD × (1 - 冷却缩减)</summary>
    public float EffectiveCooldown
        => stats != null ? stats.ApplyCooldownReduction(totalCD) : totalCD;

    // ==========================================
    // 1. 超时检测 (给 PlayerStateMachine 的 Update 用)
    // ==========================================
    public void UpdateTimeout()
    {
        // 如果打了一段且没打满，检查是否超时
        if (currentCombo > 0 && currentCombo < maxCombo)
        {
            if (Time.time - cdStartTime > comboWindow)
            {
                Debug.Log("[ComboSkill] 派生超时！已自动转入大CD");
                currentCombo = 0;
            }
        }
    }

    // ==========================================
    // 2. 准入拦截
    // ==========================================
    public bool CanExecute()
    {
        if (currentCombo == 0)
        {
            // 首段：检测大CD（已套用冷却缩减）
            return (Time.time - cdStartTime >= EffectiveCooldown);
        }
        else
        {
            // 派生段：检测连按硬直（防连击宏）
            return (Time.time - lastTapTime >= interval);
        }
    }

    // ==========================================
    // 3. 执行推进
    // ==========================================
    public void Execute()
    {
        lastTapTime = Time.time;
        currentCombo++;

        // 满段即归零（核心防白嫖逻辑）
        if (currentCombo >= maxCombo)
        {
            currentCombo = 0;
            cdStartTime = Time.time; // 满段立刻触发大CD
        }
    }

    // ==========================================
    // 4. 记录大CD/超时时间 (给卡带 Exit 用)
    // ==========================================
    public void StartCooldownIfFirstHit(bool isFirstHit)
    {
        if (isFirstHit && currentCombo != 0)
        {
            cdStartTime = Time.time;
        }
    }

    /// <summary>剩余CD秒数，供 UI 显示。已套用冷却缩减</summary>
    public float GetRemainingCooldown()
    {
        if (currentCombo != 0) return 0f;
        float remaining = EffectiveCooldown - (Time.time - cdStartTime);
        return Mathf.Max(0f, remaining);
    }
}
