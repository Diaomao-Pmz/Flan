using UnityEngine;
using Flandre.CombatSystem.Modules;

namespace Flandre.CombatSystem.Keymodules
{
    /// <summary>
    /// Echo (回响) 主动技能模块。
    ///
    /// ==========================================================
    /// 【批次A 改动】属性加成改用「便利贴」模式
    ///
    /// 原写法：
    ///   OnEquip:   state.stats.cooldownReduction += 0.15f;
    ///   OnUnequip: state.stats.cooldownReduction -= 0.15f;
    ///
    /// 这种「装备时加、卸载时手动减」的写法有两个问题：
    ///   1. 全靠程序员记得写对称的那一半。漏一次，加成就永久残留。
    ///   2. 如果中途有别的系统也改了同一个值，减回去的数就不对了。
    ///
    /// 新写法：贴便利贴 + 按签名撕。
    ///   OnEquip:   往属性上贴一张签了名(this)的便利贴
    ///   OnUnequip: 说一句「把我签名的全撕了」，墙面自动恢复原样
    ///
    /// 好处：不可能漏减，也不可能减错。
    ///       这就是「只装不卸」这类 bug 在结构上被根除的方式。
    /// ==========================================================
    /// </summary>
    public class EchoModule : IKeymodule
    {
        public string ModuleName => "Echo (回响)";

        private PlayerController controller;
        private PlayerState state;

        private bool isRecording = false;
        private float recordTimer = 0f;
        private const float MaxRecordTime = 1.0f;

        // 被动加成数值
        private const float CooldownReductionBonus = 0.15f;   // 减CD 15%
        private const float ComboWindowBonus = 0.2f;          // 连招宽恕期 +0.2 秒

        private Vector3 savedPosition;
        private Vector2 savedVelocity;
        private int savedFacingDirection;

        public EchoModule(PlayerController playerContext)
        {
            this.controller = playerContext;
            this.state = playerContext.GetComponent<PlayerState>();
        }

        public void OnEquip()
        {
            if (state == null) return;

            Debug.Log($"[{ModuleName}] 已装备：激活全局被动。");

            // 贴便利贴，签名是 this
            state.stats.cooldownReduction.AddModifier(
                StatModifier.Flat(CooldownReductionBonus, this));

            state.stats.comboWindowTolerance.AddModifier(
                StatModifier.Flat(ComboWindowBonus, this));
        }

        public void OnUnequip()
        {
            if (state == null) return;

            Debug.Log($"[{ModuleName}] 已卸载：注销全局被动。");

            // 一句话撕掉自己在【所有】属性上贴的便利贴。
            // 不需要逐条属性去减，也不可能漏掉某一条。
            int removed = state.stats.RemoveAllModifiersFrom(this);
            Debug.Log($"[{ModuleName}] 已移除 {removed} 条属性修饰。");

            // 卸载时也要清理运行时状态，别把脏数据留下
            isRecording = false;
            recordTimer = 0f;
        }

        public void UpdateModule(float deltaTime)
        {
            if (isRecording)
            {
                recordTimer -= deltaTime;
                if (recordTimer <= 0f)
                {
                    isRecording = false;
                    Debug.Log($"[{ModuleName}] 1秒时间到，回响记录消散。");
                }
            }
        }

        public void ExecuteActive()
        {
            if (controller == null) return;

            if (!isRecording)
            {
                // 第一段：记录当前状态
                savedPosition = controller.transform.position;
                savedVelocity = controller.rb.linearVelocity;
                savedFacingDirection = controller.facingDirection;

                isRecording = true;
                recordTimer = MaxRecordTime;

                Debug.Log($"[{ModuleName}] 第一段释放：已记录状态！1秒内可重放！");
            }
            else
            {
                // 第二段：重放
                controller.transform.position = savedPosition;
                controller.rb.linearVelocity = savedVelocity;
                controller.SetFacingDirection(savedFacingDirection);

                isRecording = false;
                Debug.Log($"[{ModuleName}] 第二段释放：动作再现！");
            }
        }
    }
}
