using UnityEngine;
using Flandre.CombatSystem;

/// <summary>
/// 【玩家数据总线 / 黑板】—— 对标敌人侧的 BossState。
///
/// 本次改动：
///   1. PlayerStats / PlayerHealth 拆到独立文件（Data 文件夹），本文件只做组装
///   2. 新增两个 Config 说明书引用，作为所有数值的唯一源头
///   3. 删除原 PlayerCombat 类（只有一个 comboWindowTolerance
///      和一个只打 Debug.Log 的死方法 SetSlideCooldown），
///      comboWindowTolerance 已并入 PlayerStats
///
/// 【安全网】两个 Config 即使忘记拖，也不会崩：
///   会自动创建一份内存中的默认实例（数值 = 你 Inspector 里的原值），
///   并打一条黄色警告提醒你去拖。
/// </summary>
public class PlayerState : MonoBehaviour, IDamageable
{
    [Header("出厂说明书 (ScriptableObject · 运行时只读)")]
    [Tooltip("位移数值总表。留空则使用脚本内置默认值并打警告")]
    public PlayerMovementConfig movementConfig;

    [Tooltip("战斗数值总表。留空则使用脚本内置默认值并打警告")]
    public PlayerCombatConfig combatConfig;

    [Header("核心数据总线")]
    public PlayerStats stats = new PlayerStats();
    public PlayerHealth health = new PlayerHealth();

    private bool isInitialized = false;

    void Awake()
    {
        EnsureInitialized();
    }

    /// <summary>
    /// 幂等初始化。
    ///
    /// 之所以做成 public 且幂等，是因为 Unity 不保证同一物体上
    /// 各个组件 Awake 的执行顺序。PlayerStateMachine 也会调用它一次，
    /// 确保无论谁先醒来，数据都已经就绪 —— 不需要去改 Script Execution Order。
    /// </summary>
    public void EnsureInitialized()
    {
        if (isInitialized) return;
        isInitialized = true;

        // ---- 安全网：Config 没拖也能跑 ----
        if (movementConfig == null)
        {
            movementConfig = ScriptableObject.CreateInstance<PlayerMovementConfig>();
            Debug.LogWarning(
                "[PlayerState] 未指定 PlayerMovementConfig，已临时创建默认配置。\n" +
                "请在 Project 窗口右键 Create > Flandre > Player > Movement Config 生成资产，" +
                "并拖到 PlayerState 组件上。（临时配置不会保存，改了也留不住）",
                this);
        }

        if (combatConfig == null)
        {
            combatConfig = ScriptableObject.CreateInstance<PlayerCombatConfig>();
            Debug.LogWarning(
                "[PlayerState] 未指定 PlayerCombatConfig，已临时创建默认配置。\n" +
                "请在 Project 窗口右键 Create > Flandre > Player > Combat Config 生成资产，" +
                "并拖到 PlayerState 组件上。（临时配置不会保存，改了也留不住）",
                this);
        }

        // ---- 从说明书灌入基础值 ----
        stats.Init(movementConfig);
        health.Init(combatConfig);
    }

    /// <summary>
    /// 【统一受伤入口】与敌人侧的 EntityBase 使用同一份契约。
    ///
    /// 击退力度不由攻击方决定 —— 这里只把「来源在我左边还是右边」翻译成方向，
    /// 真正的力度由 PlayerCombatConfig.hitKnockbackForce 配置、HitState 读取。
    /// 因此以后要加霸体、击退抗性、受击方向修正，只需改这一处。
    /// </summary>
    public void TakeDamage(in DamageInfo info)
    {
        float dx = transform.position.x - info.sourcePosition.x;

        // 与 HitState 的既有判定保持一致：
        // 差值过小时传 zero，让 HitState 回退到「按玩家朝向向后击飞」。
        Vector2 hitDirection = Mathf.Abs(dx) > 0.01f
            ? new Vector2(Mathf.Sign(dx), 0f)
            : Vector2.zero;

        health.TakeDamage(info.amount, hitDirection, this);
    }
}
