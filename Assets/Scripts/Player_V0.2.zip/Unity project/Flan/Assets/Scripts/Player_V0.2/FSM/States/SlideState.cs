using UnityEngine;
using Flandre.CombatSystem;

/// <summary>
/// 滑铲状态。跑动中按 C 触发，速度衰减到阈值后自动转入蹲下。
///
/// 【批次A 改动 · P0】移除两处旧输入系统调用：
///   1. Enter() 里的「双保险读取」 Input.GetAxisRaw("Horizontal")
///      —— 虚拟手柄已经是唯一可信来源，双保险反而是隐患
///   2. HandleFallback() 里的 Input.GetAxisRaw("Horizontal")
///
/// 【本次刻意未动 · 后续阶段处理】
///   - Relay 分支 → 阶段2
///   - isRejected 与 Enter 内切状态 → 阶段3
///   - 物理写在 Update() → 阶段4
///   - 与 DashState 几乎逐字重复的 Relay/HandleFallback 代码 → 阶段4 抽公共方法
/// </summary>
public class SlideState : IState
{
    private PlayerStateMachine sm;
    private float currentSlideSpeed;
    private float slideDirection;
    private bool isFirstHit;
    private bool isRejected;

    private readonly int playerLayer = LayerMask.NameToLayer("Player");
    private readonly int invincibleLayer = LayerMask.NameToLayer("Invincible");

    public SlideState(PlayerStateMachine stateMachine) { sm = stateMachine; }

    public void Enter()
    {
        isRejected = false;
        sm.playerController.loadoutManager.ExecuteActionModifier(ActionType.Slide);

        if (!sm.slideSkill.CanExecute())
        {
            Debug.LogWarning("[Slide] CD或硬直中！拦截执行");
            isRejected = true;
            HandleFallback();
            return;
        }

        isFirstHit = (sm.slideSkill.currentCombo == 0);
        sm.slideSkill.Execute();

        // ==========================================
        // 【逻辑分流 1】Relay 第二段：强制传送并退出
        // ==========================================
        if (!isFirstHit && sm.isSlideRelay)
        {
            sm.transform.position = sm.slideAnchorPos;
            sm.rb.linearVelocity = Vector2.zero;
            Debug.Log("[Slide] Relay 传送触发！");

            isRejected = true;
            HandleFallback();
            return;
        }

        // ==========================================
        // 【逻辑分流 2】常规滑铲 (含首滑与 Echo 的二滑)
        // ==========================================
        if (isFirstHit && sm.isSlideRelay)
        {
            sm.slideAnchorPos = sm.transform.position;
            sm.gameObject.layer = invincibleLayer;

            if (sm.anchorPrefab != null)
                sm.activeSlideAnchor = GameObject.Instantiate(sm.anchorPrefab, sm.slideAnchorPos, Quaternion.identity);
        }

        // ----- 正常滑铲的物理与视觉表现 -----
        Debug.Log("进入了：滑铲状态");
        sm.anim.Play("Flandre_Slide");

        sm.SetColliderHeight(true);
        if (sm.dashTrail != null) sm.dashTrail.emitting = true;

        currentSlideSpeed = sm.moveSpeed * sm.slideStartSpeedMultiplier;

        // 【批次A 改动 · P0】原先这里做了「双保险读取」：
        //   float inputX = sm.playerController.moveInput.x;
        //   if (inputX == 0) inputX = Input.GetAxisRaw("Horizontal");
        // 后半句用了旧输入系统。虚拟手柄本身已经是唯一可信来源，删掉双保险。
        float inputX = sm.playerController.moveInput.x;

        if (Mathf.Abs(inputX) > 0.1f)
        {
            slideDirection = Mathf.Sign(inputX);

            // 防「倒着滑」的视觉 Bug，强制让身体翻转过去匹配滑铲方向
            sm.playerController.SetFacingDirection(slideDirection > 0 ? 1 : -1);
        }
        else
        {
            slideDirection = sm.playerController.facingDirection;
        }
    }

    public void Update()
    {
        currentSlideSpeed -= sm.slideDeceleration * Time.deltaTime;
        sm.rb.linearVelocity = new Vector2(slideDirection * currentSlideSpeed, sm.rb.linearVelocity.y);

        // 速度衰减到阈值 → 自然转入蹲下（这就是「蹲不是独立入口」的实现处）
        float targetCrouchSpeed = sm.moveSpeed * sm.crouchSpeedMultiplier;

        if (currentSlideSpeed <= targetCrouchSpeed) sm.ChangeState(sm.crouchState);
        else if (!sm.IsGrounded()) sm.ChangeState(sm.fallState);
    }

    public void Exit()
    {
        if (isRejected) return;

        if (sm.isSlideRelay) sm.gameObject.layer = playerLayer;

        sm.slideSkill.StartCooldownIfFirstHit(isFirstHit);
        if (sm.dashTrail != null) sm.dashTrail.emitting = false;

        sm.SetColliderHeight(false);
    }

    private void HandleFallback()
    {
        // 【批次A 改动 · P0】原 Input.GetAxisRaw("Horizontal") → 虚拟手柄
        float moveInputX = sm.playerController.moveInput.x;

        if (!sm.IsGrounded())
        {
            sm.ChangeState(sm.fallState);
        }
        else if (Mathf.Abs(sm.rb.linearVelocity.x) > 0.1f || Mathf.Abs(moveInputX) > 0.1f)
        {
            sm.ChangeState(sm.runState);
        }
        else
        {
            sm.ChangeState(sm.idleState);
        }
    }
}
