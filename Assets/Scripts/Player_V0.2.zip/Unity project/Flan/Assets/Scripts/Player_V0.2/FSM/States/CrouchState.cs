using UnityEngine;

/// <summary>
/// 蹲下状态。
///
/// 按你的设计，蹲【不是】独立入口，而是滑铲的自然终点：
///   跑动中按 C → 滑铲 → 速度衰减到阈值 → 蹲下 → 松开 C 且头顶无障碍 → 站起
///
/// ==========================================================
/// 【批次A 改动 · P0】彻底移除旧输入系统
///
/// 原代码：
///   if (!Input.GetKey(KeyCode.LeftControl) && sm.CanStand())
///   if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D))
///   if (Input.GetKey(KeyCode.A)) moveDir = -1f;
///
/// 两个致命问题：
///   1. Project Settings 的 Active Input Handling 若设为
///      "Input System Package (New)"，Input.GetKey 会直接抛异常。
///   2. 就算没抛，玩家一旦改键把蹲改成 C，进入蹲下状态后
///      LeftControl 永远为 false → 下一帧立刻站起来，根本蹲不住。
///
/// 比喻：项目已经建好了统一的配电箱（PlayerController），
///       但这个房间偷偷凿了个洞、自己拉了根电线直连插座。
///       平时看不出来，一换电表（改键/上手柄）整个房间就莫名其妙断电。
///
/// 现在统一向虚拟手柄索要状态。
/// ==========================================================
/// </summary>
public class CrouchState : IState
{
    private PlayerStateMachine sm;

    public CrouchState(PlayerStateMachine stateMachine)
    {
        sm = stateMachine;
    }

    public void Enter()
    {
        Debug.Log("进入了：蹲下状态");
        sm.anim.Play("Flandre_Crouch");

        // 缩小碰撞体，贴合地面
        sm.SetColliderHeight(true);
    }

    public void Update()
    {
        // 从虚拟手柄读取，而不是直接问键盘
        bool isCrouchHeld = sm.playerController.isCrouchHeld;
        float moveDir = sm.playerController.moveInput.x;

        // 1. 什么时候才能站起来？
        //    必须同时满足：【没有按住蹲键】 且 【头顶没有障碍物】
        if (!isCrouchHeld && sm.CanStand())
        {
            // 手感细节：站起的瞬间如果正按着方向键，直接切跑动，无缝衔接
            if (Mathf.Abs(moveDir) > 0.1f)
            {
                sm.ChangeState(sm.runState);
            }
            else
            {
                sm.ChangeState(sm.idleState);
            }
            return;
        }

        // ==========================================
        // 走到这里说明：要么【还在按蹲键】，要么【头顶有墙被迫蹲着】
        // 2. 蹲行逻辑（无需按住蹲键，只要在蹲下状态就能走）
        // ==========================================

        // 蹲行速度倍率原先在这里硬编码为 0.5，现已挪进 PlayerMovementConfig
        float crouchSpeed = sm.moveSpeed * sm.crouchMoveSpeedMultiplier;
        sm.rb.linearVelocity = new Vector2(moveDir * crouchSpeed, sm.rb.linearVelocity.y);

        // 控制翻转
        if (moveDir < -0.1f) sm.playerController.SetFacingDirection(-1);
        else if (moveDir > 0.1f) sm.playerController.SetFacingDirection(1);

        // 3. 悬崖防掉落
        if (!sm.IsGrounded())
        {
            sm.ChangeState(sm.fallState);
        }
    }

    public void Exit()
    {
        Debug.Log("离开了：蹲下状态");
        sm.SetColliderHeight(false);
    }
}
