using UnityEngine;
using System.Collections.Generic;
using Flandre.CombatSystem;

// ==========================================================
// 【批次A 改动 1 · P0】
// 原第4行的  using UnityEditor.Search;  已删除。
//
// 那是编辑器专属命名空间，混进运行时脚本后：
// 在 Editor 里跑得好好的，一点 Build 就编译失败，包永远打不出来。
// 它是误自动补全进来的，删掉不影响任何功能。
// ==========================================================

public class ComboInputBuffer : MonoBehaviour
{
    [Header("连招树根节点 (起手招式)")]
    public List<ComboNode> rootNodes = new List<ComboNode>();
    public ComboNode currentNode { get; private set; }

    [Header("工业级 ACT 手感配置")]
    [Tooltip("预输入缓存时间：玩家提前多久按键能被系统记住")]
    public float bufferLifespan = 0.2f;

    // ==========================================
    // 预输入缓存核心变量 (支持蓄力时长)
    // ==========================================
    private bool hasBufferedInput = false;
    private InputCmd bufferedCmd;
    private float bufferedHoldTime = 0f;
    private float bufferTimer = 0f;

    // 延迟派生宽限期
    private bool isGracePeriodActive = false;
    private float graceTimer = 0f;

    private PlayerStateMachine sm;
    private LoadoutManager loadout;
    private PlayerController player;
    private PlayerState state;

    // 【批次A 新增】复用的搜索列表，避免每帧 new List 产生 GC
    private static readonly List<ComboNode> EmptyNodeList = new List<ComboNode>();

    void Awake()
    {
        sm = GetComponent<PlayerStateMachine>();
        loadout = GetComponent<LoadoutManager>();
        player = GetComponent<PlayerController>();
        state = GetComponent<PlayerState>();
    }

    /// <summary>
    /// 【批次A 改动 2】接通连招宽恕期的额外宽容度。
    ///
    /// EchoModule 一直在往 comboWindowTolerance 记账（+0.2秒），
    /// 但从来没有任何代码读过它。本次接通。
    /// </summary>
    private float ComboWindowTolerance
        => state != null ? state.stats.comboWindowTolerance.Value : 0f;

    void Update()
    {
        // 1. 预输入缓存倒计时
        if (hasBufferedInput)
        {
            bufferTimer -= Time.deltaTime;
            if (bufferTimer <= 0)
            {
                hasBufferedInput = false;
            }
        }

        // 2. 延迟派生宽限期倒计时（已计入宝石提供的宽容度）
        if (isGracePeriodActive && currentNode != null)
        {
            graceTimer += Time.deltaTime;
            if (graceTimer > currentNode.comboWindow + ComboWindowTolerance)
            {
                Debug.Log("[ComboBuffer] 连招宽限期超时，彻底断档！");
                ResetCombo();
            }
        }

        if (player != null) // 安全锁：残缺的测试假人没有 Controller
        {
            if (player.isMainAttackHeld && !player.isMainChargeConsumed)
            {
                TryAutoExecuteCharge(InputCmd.MainAttack, player.mainAttackHoldTime);
            }
            if (player.isSubAttackHeld && !player.isSubChargeConsumed)
            {
                TryAutoExecuteCharge(InputCmd.SubAttack, player.subAttackHoldTime);
            }
        }
    }

    // ==================================================
    // 接口 1：接收常规按下指令
    // ==================================================
    public void OnReceiveInput(InputCmd cmd)
    {
        // 飞行状态按攻击键，不存缓存，直接驳回
        if (sm.currentState == sm.flyState && (cmd == InputCmd.MainAttack || cmd == InputCmd.SubAttack))
        {
            return;
        }

        // 受身打断 (Combo Breaker)
        if (sm != null && sm.currentState == sm.hitState)
        {
            if (CheckIfHasShieldGem(cmd))
            {
                if (cmd == InputCmd.Jump) sm.ChangeState(sm.jumpState);
                if (cmd == InputCmd.Dash) sm.ChangeState(sm.dashState);
                return;
            }
            return;
        }

        // 纯位移动作类指令 - 立刻放行
        // (阶段3 会整体搬去 PlayerCommandRouter，并改为「守卫前置」)
        if (cmd == InputCmd.Jump || cmd == InputCmd.Dash)
        {
            if (cmd == InputCmd.Dash && sm.dashSkill.CanExecute()) sm.ChangeState(sm.dashState);
            if (cmd == InputCmd.Jump && sm.jumpCount < sm.maxJumps) sm.ChangeState(sm.jumpState);
            return;
        }

        // 攻击类指令 (主/副攻击同等地位) - 存入预输入缓存
        if (cmd == InputCmd.MainAttack || cmd == InputCmd.SubAttack)
        {
            hasBufferedInput = true;
            bufferedCmd = cmd;
            bufferedHoldTime = 0f;
            bufferTimer = bufferLifespan;

            if (sm.currentState != sm.comboState) TryAdvanceCombo();
        }
    }

    // ==================================================
    // 接口 2：接收蓄力松开指令
    // ==================================================
    public void OnReceiveChargeRelease(InputCmd cmd, float holdTime)
    {
        hasBufferedInput = true;
        bufferedCmd = cmd;
        bufferedHoldTime = holdTime;
        bufferTimer = bufferLifespan;

        if (sm.currentState != sm.comboState) TryAdvanceCombo();
    }

    private void TryAutoExecuteCharge(InputCmd cmd, float currentHoldTime)
    {
        // 【批次A 改动 3 · 零分配】
        // 原写法：(currentNode.childNodes ?? new List<ComboNode>())
        // 蓄力期间每帧 new 一个 List，与 readme 的「零分配」目标直接冲突。
        // 改为复用静态空列表。
        List<ComboNode> searchList;
        if (currentNode == null)
        {
            searchList = rootNodes;
        }
        else
        {
            searchList = currentNode.childNodes ?? EmptyNodeList;
        }

        ComboNode match = FindBestMatch(searchList, cmd, currentHoldTime);

        if (match != null && match.isChargeSkill)
        {
            Debug.Log($"[ComboBuffer] 蓄力达标！自动释放技能: {match.name}");

            if (cmd == InputCmd.MainAttack) player.ConsumeMainCharge();
            if (cmd == InputCmd.SubAttack) player.ConsumeSubCharge();

            hasBufferedInput = false;
            isGracePeriodActive = false;

            currentNode = match;
            sm.ChangeState(sm.comboState);
        }
    }

    // ==================================================
    // 核心匹配引擎
    // ==================================================
    public bool TryAdvanceCombo()
    {
        if (!hasBufferedInput) return false;

        ComboNode match = (currentNode == null)
            ? FindBestMatch(rootNodes, bufferedCmd, bufferedHoldTime)
            : FindBestMatch(currentNode.childNodes, bufferedCmd, bufferedHoldTime);

        if (match != null)
        {
            currentNode = match;
            ExecuteNode();
            return true;
        }

        return false;
    }

    private ComboNode FindBestMatch(List<ComboNode> nodes, InputCmd triggerCmd, float holdTime)
    {
        if (nodes == null) return null;

        ComboNode bestMatch = null;
        int maxSequenceLength = -1; // 优先级：要求越多的连招优先级越高

        foreach (var node in nodes)
        {
            if (node == null) continue;

            // 1. 环境限制
            if (node.castCondition == CastCondition.GroundOnly && !sm.IsGrounded()) continue;
            if (node.castCondition == CastCondition.AirOnly && sm.IsGrounded()) continue;

            // 2. 前置状态限制
            if (!IsRequiredStateMet(node.requiredState)) continue;

            // 3. 蓄力条件
            if (node.isChargeSkill)
            {
                if (holdTime < node.requiredChargeTime) continue;
            }
            else
            {
                // 普通技能只能由瞬间按下触发，防止松开蓄力时误打出普攻
                if (holdTime > 0f) continue;
            }

            // 4. 组合键序列
            if (node.inputSequence.Count == 0) continue;
            if (node.inputSequence[node.inputSequence.Count - 1] != triggerCmd) continue;

            bool isSequenceMatched = true;
            for (int i = 0; i < node.inputSequence.Count - 1; i++)
            {
                if (!IsDirectionalCommandHeld(node.inputSequence[i]))
                {
                    isSequenceMatched = false;
                    break;
                }
            }
            if (!isSequenceMatched) continue;

            // 5. 优先级对决
            if (node.inputSequence.Count > maxSequenceLength)
            {
                maxSequenceLength = node.inputSequence.Count;
                bestMatch = node;
            }
        }

        return bestMatch;
    }

    // ==================================================
    // 辅助验证器
    // ==================================================
    private bool IsRequiredStateMet(RequiredState req)
    {
        if (req == RequiredState.Any) return true;
        if (req == RequiredState.IdleOrRun) return (sm.currentState == sm.idleState || sm.currentState == sm.runState);
        if (req == RequiredState.Dash) return sm.currentState == sm.dashState;
        if (req == RequiredState.Slide) return sm.currentState == sm.slideState;
        if (req == RequiredState.Crouch) return sm.currentState == sm.crouchState;
        return false;
    }

    private bool IsDirectionalCommandHeld(InputCmd cmd)
    {
        if (cmd == InputCmd.Up) return sm.playerController.moveInput.y > 0.1f;
        if (cmd == InputCmd.Down) return sm.playerController.moveInput.y < -0.1f;
        if (cmd == InputCmd.Left) return sm.playerController.moveInput.x < -0.1f;
        if (cmd == InputCmd.Right) return sm.playerController.moveInput.x > 0.1f;
        return false;
    }

    private void ExecuteNode()
    {
        hasBufferedInput = false;
        isGracePeriodActive = false;
        sm.ChangeState(sm.comboState);
    }

    public void StartGracePeriod()
    {
        isGracePeriodActive = true;
        graceTimer = 0f;
    }

    public void ResetCombo()
    {
        currentNode = null;
        isGracePeriodActive = false;
        hasBufferedInput = false;
    }

    private bool CheckIfHasShieldGem(InputCmd cmd)
    {
        if (loadout == null) return false;
        return loadout.HasShieldGem(cmd);
    }
}
