using UnityEngine;
using UnityEngine.InputSystem;
using Flandre.CombatSystem;

[RequireComponent(typeof(Rigidbody2D), typeof(ComboInputBuffer))]
public class PlayerController : MonoBehaviour
{
    [Header("Ӳ��������Բ�����")]
    public Rigidbody2D rb { get; private set; }
    public SpriteRenderer sr { get; private set; }
    public Animator anim { get; private set; }

    public PlayerStateMachine stateMachine;
    public LoadoutManager loadoutManager;
    public ComboInputBuffer inputBuffer { get; private set; }
    private Coroutine blinkCoroutine;

    [Header("�����ֱ��ź� (Virtual Gamepad)")]
    public Vector2 moveInput { get; private set; }
    public int facingDirection = 1;

    // ==========================================
    // ������ѹ������״̬��¼��
    public bool isJumpHeld { get; private set; }
    public bool isCrouchHeld { get; private set; }
    public bool isFlyHeld { get; private set; } 

    public bool isMainAttackHeld { get; private set; }
    public float mainAttackHoldTime { get; private set; }
    public bool isMainChargeConsumed { get; private set; } 

    public bool isSubAttackHeld { get; private set; }
    public float subAttackHoldTime { get; private set; }
    public bool isSubChargeConsumed { get; private set; } 

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();

        stateMachine = GetComponent<PlayerStateMachine>();
        loadoutManager = GetComponent<LoadoutManager>();
        inputBuffer = GetComponent<ComboInputBuffer>();
    }

    void Update()
    {
        bool isHit = (stateMachine != null && stateMachine.currentState == stateMachine.hitState);

        // ==========================================
        // ������������߼� (˫�������ʱ)
        // ==========================================
        if (!isHit)
        {
            if (isMainAttackHeld) mainAttackHoldTime += Time.deltaTime;
            if (isSubAttackHeld) subAttackHoldTime += Time.deltaTime;
        }
    }

    // ==========================================
    // ����ϵͳ�ص� (�Խ� Player Input Events)
    // ==========================================
    public void OnMove(InputAction.CallbackContext ctx)
    {
        moveInput = ctx.ReadValue<Vector2>();
    }

    public void OnJumpPerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.started) // �հ��µ�˲��
        {
            isJumpHeld = true;

            // ����Է��ͳ�����Ծ����ָ��
            inputBuffer.OnReceiveInput(InputCmd.Jump);
        }
        else if (ctx.canceled) // ��ָ�ɿ���˲��
        {
            isJumpHeld = false;
        }
    }

    public void OnDashPerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.performed) inputBuffer.OnReceiveInput(InputCmd.Dash);
    }

    // ���� / �¶� (���ü�)
    public void OnCrouchSlidePerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.started) isCrouchHeld = true;
        else if (ctx.canceled) isCrouchHeld = false;
    }

    // ��������������ר�ü�����
    public void OnFlyPerformed(InputAction.CallbackContext ctx)
    {
        // ֻ��Ҫ�� FallState �� FlyState ��ȡ����ֵ������ Buffer ������
        if (ctx.started) isFlyHeld = true;
        else if (ctx.canceled) isFlyHeld = false;
    }

    // ==========================================
    // ��/��������˲�䴥���������ͷ�
    // ==========================================
    public void OnMainAttackPerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.started)
        {
            isMainAttackHeld = true;
            isMainChargeConsumed = false; 
            mainAttackHoldTime = 0f;
            inputBuffer.OnReceiveInput(InputCmd.MainAttack);
        }
        else if (ctx.canceled)
        {
            isMainAttackHeld = false;

            if (!isMainChargeConsumed)
            {
                inputBuffer.OnReceiveChargeRelease(InputCmd.MainAttack, mainAttackHoldTime);
            }
        }
    }

    public void OnSubAttackPerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.started)
        {
            isSubAttackHeld = true;
            isSubChargeConsumed = false; 
            subAttackHoldTime = 0f;
            inputBuffer.OnReceiveInput(InputCmd.SubAttack);
        }
        else if (ctx.canceled)
        {
            isSubAttackHeld = false;

            if (!isSubChargeConsumed)
            {
                inputBuffer.OnReceiveChargeRelease(InputCmd.SubAttack, subAttackHoldTime);
            }
        }
    }

    public void ConsumeMainCharge() { isMainChargeConsumed = true; }
    public void ConsumeSubCharge() { isSubChargeConsumed = true; }

    // ==========================================
    // ����
    // ==========================================
    public void SetFacingDirection(int dir)
    {
        // 1. ��¼�������� (-1 �� 1)
        facingDirection = dir;

        // 2. �������� sr.flipX������ Transform �� 3D ��ת
        if (dir == 1)
        {
            // �泯�ң�Y����ת���㡣����������ָ�Ĭ��λ�á�
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        else if (dir == -1)
        {
            // �泯��Y����ת180�ȡ����������������壨��Ч���ж���������ת����һ�ߣ�
            transform.rotation = Quaternion.Euler(0, 180, 0);
        }
    }

    public void StartBlink(float duration, float interval)
    {
        if (blinkCoroutine != null) StopCoroutine(blinkCoroutine);
        blinkCoroutine = StartCoroutine(BlinkRoutine(duration, interval));
    }

    private System.Collections.IEnumerator BlinkRoutine(float duration, float interval)
    {
        float elapsed = 0f;
        if (interval <= 0) interval = 0.1f;

        while (elapsed < duration)
        {
            sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, 0f);
            yield return new WaitForSeconds(interval);
            elapsed += interval;

            sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, 1f);
            yield return new WaitForSeconds(interval);
            elapsed += interval;
        }
        sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, 1f);
    }
}