using UnityEngine;
using UnityEngine.InputSystem;
using Flandre.CombatSystem;

/// <summary>
/// 【虚拟手柄】—— 全项目唯一允许接触 Input System 的文件。
///
/// ==========================================================
/// 【批次C 改动】
///
/// 1. C 键从"只置一个 bool"升级为"置 bool + 发脉冲"。
///
///    为什么两者都要？
///      脉冲(InputCmd.Crouch) → 表达"按下的那一瞬间"，用于触发滑铲/蹲下，
///                              享受预输入宽恕
///      持续(isCrouchHeld)    → 表达"还按着"，用于判断能不能站起来
///    这两个语义不同，缺一不可。
///
/// 2. 位移指令（跳/冲/蹲铲）改为发给 PlayerCommandRouter，
///    不再发给 ComboInputBuffer。
///
///    原因：ComboInputBuffer 的本职是连招匹配，
///          它同时兼任位移指令分发是越权。现在各归各位：
///            攻击键 → ComboInputBuffer
///            位移键 → PlayerCommandRouter
/// ==========================================================
/// </summary>
[RequireComponent(typeof(Rigidbody2D), typeof(ComboInputBuffer))]
[RequireComponent(typeof(PlayerCommandRouter))]
public class PlayerController : MonoBehaviour
{
    [Header("硬件与核心脑部引用")]
    public Rigidbody2D rb { get; private set; }
    public SpriteRenderer sr { get; private set; }
    public Animator anim { get; private set; }

    public PlayerStateMachine stateMachine;
    public LoadoutManager loadoutManager;
    public ComboInputBuffer inputBuffer { get; private set; }
    public PlayerCommandRouter commandRouter { get; private set; }
    private Coroutine blinkCoroutine;

    [Header("虚拟手柄信号 (Virtual Gamepad)")]
    public Vector2 moveInput { get; private set; }
    public int facingDirection = 1;

    /// <summary>
    /// 鼠标/指针的屏幕坐标。由 PlayerAimProvider 转成世界方向。
    ///
    /// 【为什么放在这里】本文件是全项目唯一允许接触 Input System 的地方。
    /// 让瞄准组件自己去读 Mouse.current 的话，这条规矩就破了 ——
    /// 以后想支持手柄右摇杆瞄准、或者做输入录制回放，会发现输入源散落在好几处。
    /// </summary>
    public Vector2 screenAimPosition { get; private set; }

    /// <summary>
    /// 这台机器上到底有没有鼠标。
    ///
    /// 【为什么需要它】PlayerAimProvider 的 Auto 模式原本用「鼠标 2 秒没动」
    /// 来判断玩家是不是换手柄了 —— 但"没动"和"没有"是两回事。
    /// 蓄力时玩家瞄准不动是常态，于是会被误判成手柄，瞄准方向悄悄
    /// 从鼠标切成方向键，AA1 的位移方向跟着一起变。
    ///
    /// 设备有无是硬件事实，该由本文件（全项目唯一碰 Input System 的地方）回答。
    /// </summary>
    public bool hasPointerDevice { get; private set; }

    /// <summary>
    /// 玩家【现在】用的是手柄还是鼠标。
    ///
    /// ==========================================================
    /// 【为什么由本文件回答，而不是让瞄准组件自己猜】
    ///
    /// PlayerAimProvider 的 Auto 模式原先靠「鼠标多久没动」来推断玩家换了手柄。
    /// 但"没动"有两种完全不同的原因：
    ///     玩家换手柄了      —— 该切八向
    ///     玩家瞄好了在等时机 —— 绝对不该切
    /// 一个信号区分不了两件事，所以必然会误判 —— 而蓄力时把鼠标停住瞄准
    /// 恰恰是常态，于是子弹会在鼠标静止一段时间后突然改朝角色正面飞，
    /// 玩家完全不知道发生了什么。
    ///
    /// 比喻：柜台"两秒没人说话就默认改说另一种语言"。真正该看的不是沉默多久，
    ///       而是【最后开口的人说的是哪种语言】。
    ///
    /// 现在改成记录事实：谁最后动过，就是谁在用。
    ///   鼠标动了     → false（用鼠标）
    ///   手柄推方向了 → true （用手柄）
    /// 停着不动时维持上一个结论，所以"瞄好了等时机"永远不会被误判。
    ///
    /// 这类硬件事实该由本文件回答 —— 它是全项目唯一碰 Input System 的地方，
    /// 和 hasPointerDevice 是同一条规矩。
    /// ==========================================================
    /// </summary>
    public bool isUsingGamepad { get; private set; }

    // ==========================================
    // 持续按压与蓄力状态记录区
    // ==========================================
    public bool isJumpHeld { get; private set; }
    public bool isCrouchHeld { get; private set; }
    public bool isFlyHeld { get; private set; }

    public bool isMainAttackHeld { get; private set; }
    public float mainAttackHoldTime { get; private set; }

    public bool isSubAttackHeld { get; private set; }
    public float subAttackHoldTime { get; private set; }

    [Header("点按 / 长按判定")]
    [Tooltip(
        "按住超过这个时长就判定为「长按」，直接进入蓄力（不打出普攻）。\n\n" +
        "代价：普攻会有同等时长的输入延迟 —— 这是「同一个键区分点按与长按」\n" +
        "必须付出的账，调小可以更跟手但更容易把长按误判成点按。")]
    public float attackHoldThreshold = 0.15f;

    // 本次按压是否已经作出「点按 / 长按」的判定。
    // 一次按压只判定一次，判定完就不再重复触发。
    private bool mainHoldResolved;
    private bool subHoldResolved;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();

        stateMachine = GetComponent<PlayerStateMachine>();
        loadoutManager = GetComponent<LoadoutManager>();
        inputBuffer = GetComponent<ComboInputBuffer>();
        commandRouter = GetComponent<PlayerCommandRouter>();
    }

    void Update()
    {
        PollPointer();

        bool isHit = (stateMachine != null && stateMachine.currentState == stateMachine.hitState);

        // 蓄力秒表走字 (双轨独立计时)
        if (!isHit)
        {
            if (isMainAttackHeld) mainAttackHoldTime += Time.deltaTime;
            if (isSubAttackHeld) subAttackHoldTime += Time.deltaTime;

            ResolveHoldIfNeeded();
        }
    }

    /// <summary>
    /// 每帧同步指针位置。
    ///
    /// 直接读 Mouse.current 而不是绑一个 Look Action，是为了少一步配置 ——
    /// 你不需要去 Input Actions 资产里新建 Action 再绑函数。
    /// 想改成 Action 驱动的话，调用下面的 OnLook 即可，两条路都留着。
    /// </summary>
    private void PollPointer()
    {
        var mouse = Mouse.current;
        hasPointerDevice = (mouse != null);
        if (mouse == null) return;

        Vector2 pos = mouse.position.ReadValue();

        // 鼠标真的动了（不是 1 像素的抖动）→ 玩家回到鼠标了。
        // 阈值与 PlayerAimProvider 里原先那套判活一致。
        if ((pos - screenAimPosition).sqrMagnitude > 1f) isUsingGamepad = false;

        screenAimPosition = pos;
    }

    /// <summary>
    /// 【可选】如果你更想用 Input Actions 驱动指针（比如要支持触屏或手柄准星），
    /// 在资产里建一个 Pass Through / Vector2 的 Look 动作，绑到这个函数即可。
    /// </summary>
    public void OnLook(InputAction.CallbackContext ctx)
    {
        screenAimPosition = ctx.ReadValue<Vector2>();
    }

    // ==========================================
    // 位移指令 → 路由器
    // ==========================================

    public void OnMove(InputAction.CallbackContext ctx)
    {
        moveInput = ctx.ReadValue<Vector2>();

        // 方向输入来自手柄 → 记下"玩家在用手柄"。
        //
        // 【只认手柄，不管键盘】键盘 + 鼠标是同一套操作方式，
        // 按 a/d 跑动不代表玩家放弃了鼠标瞄准 —— 那正是最常见的玩法。
        // 只有手柄摇杆才意味着"这个人手上没有鼠标可用"。
        if (ctx.control != null && ctx.control.device is Gamepad) isUsingGamepad = true;
    }

    /// <summary>跳跃键（Space）。飞行中按无效（路由器会拒绝）</summary>
    public void OnJumpPerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.started)
        {
            isJumpHeld = true;
            commandRouter.OnCommand(InputCmd.Jump);
        }
        else if (ctx.canceled)
        {
            isJumpHeld = false;
        }
    }

    public void OnDashPerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.performed) commandRouter.OnCommand(InputCmd.Dash);
    }

    /// <summary>
    /// 滑铲 / 下蹲（共用 C 键）。
    ///
    /// 【批次C 改动】按下的瞬间额外发出 Crouch 脉冲。
    /// "变成铲还是变成蹲"由路由器判断 —— 那是决策层的事，不是输入层的事。
    /// </summary>
    public void OnCrouchSlidePerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.started)
        {
            isCrouchHeld = true;
            commandRouter.OnCommand(InputCmd.Crouch);
        }
        else if (ctx.canceled)
        {
            isCrouchHeld = false;
        }
    }

    /// <summary>
    /// 飞行键（左 Alt）。【按下即发】一次 InputCmd.Fly —— 它是个开关：
    ///   没在飞（地面、起跳中、下落中都算）→ 起飞
    ///   正在飞                           → 解除飞行，自然下落
    /// 裁决在 PlayerCommandRouter.TryToggleFly（蓝量、攻击/后摇闸门都在那里）。
    /// isFlyHeld 只是如实记录按键状态，目前没有逻辑依赖它。
    /// </summary>
    public void OnFlyPerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.started)
        {
            isFlyHeld = true;
            commandRouter.OnCommand(InputCmd.Fly);
        }
        else if (ctx.canceled)
        {
            isFlyHeld = false;
        }
    }

    /// <summary>
    /// 主动技能键。
    ///
    /// 目前 PlayerInputConfig 里可能还没有这个 Action —— 需要你在
    /// Input Actions 资产里新建一个（建议绑 R 或 E），然后把这个函数绑上去。
    /// 不绑也不影响编译与运行。
    /// </summary>
    public void OnActiveSkillPerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.performed) loadoutManager?.TriggerActiveSkill();
    }

    // ==========================================
    // 攻击指令 → 连招引擎
    // ==========================================

    /// <summary>
    /// 【P1a 重写】攻击键改为「点按 / 长按」二选一。
    ///
    /// 按下的那一刻【什么都不做】—— 因为还分不清玩家想干嘛：
    ///   0.15 秒内松手  → 点按 → 打出普攻
    ///   0.15 秒后仍按着 → 长按 → 直接进蓄力（不打出普攻）
    ///
    /// 旧版是"按下立刻出普攻，动画放完还按着才进蓄力"（效仿空洞骑士），
    /// 新规则把那一发普攻删掉了，用这段判定延迟来分离两种意图。
    ///
    /// 代价是普攻有 0.15 秒输入延迟，这是同一个键承担两种用法必然要付的账。
    ///
    /// 【飞行中例外】飞行时没有蓄力，也就不需要区分点按和长按 ——
    /// 按下立刻出招（按住连发由 FlyCombatState 读 isXxxAttackHeld 实现）。
    /// 这次按压直接标记为"已判定"，松手时不会再补发一次点按普攻。
    /// </summary>
    public void OnMainAttackPerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.started)
        {
            isMainAttackHeld = true;
            mainAttackHoldTime = 0f;
            mainHoldResolved = false;

            if (inputBuffer != null && inputBuffer.OnAttackPressedInFlight(InputCmd.MainAttack))
                mainHoldResolved = true;
        }
        else if (ctx.canceled)
        {
            isMainAttackHeld = false;

            if (!mainHoldResolved)
            {
                // 还没到长按阈值就松手 → 点按 → 普攻
                mainHoldResolved = true;
                inputBuffer.OnAttackTap(InputCmd.MainAttack);
            }
            else
            {
                // 已判定为长按 → 交给连招引擎结算这次蓄力（蓄满就放，没蓄满就血本无归），
                // 顺带清掉预输入缓存，免得松手后又跑出来打一发普攻
                inputBuffer.OnAttackReleased(InputCmd.MainAttack);
            }
        }
    }

    public void OnSubAttackPerformed(InputAction.CallbackContext ctx)
    {
        if (ctx.started)
        {
            isSubAttackHeld = true;
            subAttackHoldTime = 0f;
            subHoldResolved = false;

            // 飞行中：按下立刻出招（同主手）
            if (inputBuffer != null && inputBuffer.OnAttackPressedInFlight(InputCmd.SubAttack))
                subHoldResolved = true;
        }
        else if (ctx.canceled)
        {
            isSubAttackHeld = false;

            if (!subHoldResolved)
            {
                subHoldResolved = true;
                inputBuffer.OnAttackTap(InputCmd.SubAttack);
            }
            else
            {
                inputBuffer.OnAttackReleased(InputCmd.SubAttack);
            }
        }
    }

    /// <summary>
    /// 按住超过阈值时，判定为长按并通知连招引擎进入蓄力。
    /// 一次按压只判定一次。
    /// </summary>
    private void ResolveHoldIfNeeded()
    {
        if (isMainAttackHeld && !mainHoldResolved
            && mainAttackHoldTime >= attackHoldThreshold)
        {
            mainHoldResolved = true;
            inputBuffer.OnAttackHold(InputCmd.MainAttack);
        }

        if (isSubAttackHeld && !subHoldResolved
            && subAttackHoldTime >= attackHoldThreshold)
        {
            subHoldResolved = true;
            inputBuffer.OnAttackHold(InputCmd.SubAttack);
        }
    }

    // 【已删除】ConsumeMainCharge / ConsumeSubCharge 与两个 isXxxChargeConsumed 标记。
    // 它们服务的是批次J 之前「蓄满自动放」的模型：放完要标记一下免得重复放。
    // 改成「松手才放」之后，松手这个动作本身就是一次性的，不需要额外的消耗标记。

    // ==========================================
    // 杂项
    // ==========================================

    public void SetFacingDirection(int dir)
    {
        facingDirection = dir;

        // 用 Transform 旋转而非 flipX：所有子物体（特效、判定框）自动跟着翻
        if (dir == 1) transform.rotation = Quaternion.Euler(0, 0, 0);
        else if (dir == -1) transform.rotation = Quaternion.Euler(0, 180, 0);
    }

    // ==========================================
    // 角色透明度（无敌半透明 + 受击闪烁）
    // ==========================================
    //
    // 【唯一写入者】sprite 的 alpha 只在 LateUpdate 里写一次。
    // 闪烁协程不再直接改颜色，只拨一个"现在该不该隐身"的开关；
    // 无敌半透明也不由各个无敌来源各自去改 —— 每帧看一眼无敌计数器就够了。
    //
    // 比喻：以前是两个人轮流往同一块屏幕上写字，谁后写谁赢；
    //       现在是两个人只递纸条，由一个人统一决定屏幕显示什么。
    // 这样以后新增任何无敌来源（技能、宝石…），外观都会自动跟上。

    /// <summary>闪烁的"隐身"那一拍</summary>
    private bool isBlinkHidden;

    private float InvulnerableAlpha
    {
        get
        {
            var ps = stateMachine != null ? stateMachine.playerState : null;
            return ps != null && ps.combatConfig != null ? ps.combatConfig.invulnerableAlpha : 0.8f;
        }
    }

    void LateUpdate()
    {
        if (sr == null) return;

        var ps = stateMachine != null ? stateMachine.playerState : null;
        bool invulnerable = ps != null && ps.health.isUntargetable;

        // 闪烁的隐身拍优先；否则无敌 → 半透明，不无敌 → 不透明
        float alpha = isBlinkHidden ? 0f : (invulnerable ? InvulnerableAlpha : 1f);

        if (!Mathf.Approximately(sr.color.a, alpha))
        {
            Color c = sr.color;
            c.a = alpha;
            sr.color = c;
        }
    }

    public void StartBlink(float duration, float interval)
    {
        if (blinkCoroutine != null) StopCoroutine(blinkCoroutine);
        isBlinkHidden = false;   // 上一轮可能停在隐身拍上
        blinkCoroutine = StartCoroutine(BlinkRoutine(duration, interval));
    }

    /// <summary>
    /// 受击闪烁：在"隐身"与"正常"之间来回切。
    /// "正常"那一拍显示多透明由 LateUpdate 决定 —— 受击期间是无敌的，所以是半透明。
    /// </summary>
    private System.Collections.IEnumerator BlinkRoutine(float duration, float interval)
    {
        float elapsed = 0f;
        if (interval <= 0) interval = 0.1f;

        while (elapsed < duration)
        {
            isBlinkHidden = true;
            yield return new WaitForSeconds(interval);
            elapsed += interval;

            isBlinkHidden = false;
            yield return new WaitForSeconds(interval);
            elapsed += interval;
        }

        isBlinkHidden = false;
        blinkCoroutine = null;
    }
}
