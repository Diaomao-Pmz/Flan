﻿using System.Collections;
using UnityEngine;

/// <summary>
/// Boss 的战斗状态。
///
/// 【本次改动】它不再认识任何具体技能。
/// 原先这里是一串 if (node is TeleportNode) / if (node is BulletNode) / else 的分支链，
/// 每加一种技能就要回来改一次。现在只做三件事：抽卡 → 查执行器 → 等它演完。
///
/// 命名说明：本类是 IState（战斗状态），真正干活的是各个 IBossActionExecutor。
/// 若日后重构，建议改名 BossCombatState，把 Executor 一词让给执行器接口。
/// </summary>
public class BossActionExecuter : IState
{
    BossController boss;
    Coroutine attackCoroutine;

    // 记录当前正在演出的执行器，被打断时好通知它收摊
    IBossActionExecutor activeExecutor;

    public BossActionExecuter(BossController bc)
    {
        boss = bc;
    }

    public void Enter()
    {
        // 防御：上一次 DoCombat 若没 yield 就直接结束（SelectSkill 返回 null），
        // StartCoroutine 返回后句柄会被赋成一个已结束的协程，导致这里永远以为"还在出招"
        attackCoroutine = null;
        activeExecutor = null;

        boss.SetMovementStatus("[移动] 出招中");

        // 每次进入战斗状态时，确保物理速度归零，专心出招（实现"射击时不移动"）
        Rigidbody2D rb = boss.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
        }
    }

    public void Exit()
    {
        // ========================================================
        // 【核心安全保护】：Boss 在出招期间被破盾（进入 StunState）或转阶段时，
        // 强制掐断协程并通知执行器收摊，防止"晕了还在射击/激光还在照"的 Bug。
        // ========================================================
        if (attackCoroutine != null)
        {
            boss.StopCoroutine(attackCoroutine);
            attackCoroutine = null;
        }

        // 【改动】不再写死 BulletEmitter.StopAttack()，改为通知当前执行器。
        // 这样以后加激光、冲撞，打断逻辑不需要再改这里。
        if (activeExecutor != null)
        {
            activeExecutor.Cancel();
            activeExecutor = null;
        }
    }

    public void FixedUpdate()
    {

    }

    public void Update()
    {
        if (attackCoroutine != null) return;

        // 进入战斗状态时意图已经就位（MoveState 判断过射程），直接出招。
        // SelectSkill 出手前还会再校验一次，不通过就返回 null → 回移动状态重新定意图。
        attackCoroutine = boss.StartCoroutine(DoCombat());
    }

    IEnumerator DoCombat()
    {
        // 1. 兑现 AI 在移动阶段定好的意图（抽出来的是基类 ActionNode）
        ActionNode actionNode = boss.AI.SelectSkill();

        if (actionNode == null)
        {
            Finish();
            yield break;
        }

        // 套路步骤的"出招前停顿"（单招为 0）。停顿期间被破盾等打断时，Exit 会掐掉本协程
        float delay = boss.AI.NextActionDelay;
        if (delay > 0f)
        {
            yield return new WaitForSeconds(delay);

            // 停顿期间玩家可能绕到背后 / 起飞了：按此刻情况重新检查这一步的候补招式
            actionNode = boss.AI.RefreshStepChoice(actionNode);
        }

        // 2. 查表找到认领这种卡的执行器。大脑到此为止，不关心它是什么技能。
        IBossActionExecutor executor = boss.GetExecutorFor(actionNode);

        if (executor == null)
        {
            Debug.LogError(
                $"[BossActionExecuter] 没有执行器认领 {actionNode.GetType().Name}" +
                $"（卡片: {actionNode.name}）。请检查对应 Executor 是否挂在 Boss 身上。");
            yield return new WaitForSeconds(1f); // 停顿一下防止空转刷屏
            Finish();
            yield break;
        }

        if (boss.bossStatusText != null)
        {
            string label = string.IsNullOrEmpty(actionNode.actionName)
                ? actionNode.name
                : actionNode.actionName;
            if (!string.IsNullOrEmpty(boss.AI.LastPickRoutineName))
                label = $"[{boss.AI.LastPickRoutineName}] {label}";
            boss.bossStatusText.SetText(label);
        }

        // 3. 交给执行器演完。
        //
        // 【注意】这里是 yield return executor.Execute(...)，而不是
        // yield return boss.StartCoroutine(executor.Execute(...))。
        // 后者会派生出一个独立的子协程，父协程被 StopCoroutine 时子协程**不会**被连带停止，
        // 打断时就会残留一个还在跑的动作。直接 yield return IEnumerator
        // 相当于把它内联进本协程，父停子必停。
        activeExecutor = executor;
        yield return executor.Execute(actionNode, boss.Context);
        activeExecutor = null;

        Finish();
    }

    /// <summary>收尾：先清协程句柄再切状态，避免 Exit() 把自己给停了。</summary>
    private void Finish()
    {
        attackCoroutine = null;
        activeExecutor = null;

        // 套路的下一步可以马上接 → 留在战斗状态，下一帧 Update 直接出下一招。
        // 不这么做的话，每一步之间都会先回移动状态走一段，套路就连不起来了。
        if (boss.AI.HasImmediateFollowUp) return;

        boss.ChangeState(boss.MoveState);
    }
}