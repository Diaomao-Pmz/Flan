using UnityEngine;

public class BossMoveState : IState
{
    private BossController boss;
    private Rigidbody2D rb;
    private float moveTimer;
    private float targetMaintainDistance; // ������������̬�洢���Է��������ž���

    public BossMoveState(BossController bc)
    {
        boss = bc;
        rb = boss.GetComponent<Rigidbody2D>();
    }

    public void Enter()
    {
        moveTimer = Random.Range(1f, 2.5f);
        boss.bossState.bossMechanic.isCornered = false;

        // �����Ľ��������� AI ��ı��������ѽӵо���
        targetMaintainDistance = boss.AI.GetOptimalEngagementDistance();

        Debug.Log($"[BossMoveState] �յ�ָ����Ա��ֶ�̬��Ѿ���: {targetMaintainDistance:F1}���ƶ����� {moveTimer:F1} ��");
    }

    public void Update()
    {
        moveTimer -= Time.deltaTime;

        if (moveTimer <= 0)
        {
            boss.ChangeState(boss.CombatState);
            return;
        }

        Vector2 playerPos = boss.PlayerTransform.position;
        Vector2 bossPos = boss.transform.position;
        float distance = Vector2.Distance(playerPos, bossPos);
        float dirX = 0f;

        // ���޸ġ���ʹ�ö�̬��ȡ�� targetMaintainDistance ���д���ı���
        if (distance < targetMaintainDistance - 0.5f)
        {
            dirX = (bossPos.x > playerPos.x) ? 1f : -1f;
        }
        else if (distance > targetMaintainDistance + 0.5f)
        {
            dirX = (playerPos.x > bossPos.x) ? 1f : -1f;
        }

        if (rb != null)
        {
            rb.linearVelocity = new Vector2(dirX * boss.moveSpeed, rb.linearVelocity.y);
        }

        if (dirX != 0)
        {
            RaycastHit2D hit = Physics2D.Raycast(bossPos, new Vector2(dirX, 0), boss.wallCheckDistance, boss.wallLayer);
            boss.bossState.bossMechanic.isCornered = (hit.collider != null);
        }
    }

    public void FixedUpdate()
    {

    }

    public void Exit()
    {
        if (rb != null) rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
    }
}